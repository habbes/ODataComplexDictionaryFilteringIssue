﻿using System.Collections.ObjectModel;

namespace Test;

public sealed class LocalizableString
{
    private ReadOnlyDictionary<string, string> _dictionary;

    /// <summary>
    /// Initializes a new instance of the <see cref="LocalizableString"/> class.
    /// </summary>
    public LocalizableString()
    {
        _dictionary = new ReadOnlyDictionary<string, string>(new Dictionary<string, string>());
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="LocalizableString"/> class from the specified dictionary.
    /// </summary>
    /// <param name="dictionary">The dictionary that contains the data to copy.</param>
    public LocalizableString(IDictionary<string, string> dictionary)
    {
        _dictionary = new ReadOnlyDictionary<string, string>(dictionary);
    }

    /// <summary>
    /// Gets the extended properties used with OData query.
    /// </summary>
    public IDictionary<string, object> ExtendedProperties
    {
        get
        {
            return _dictionary.ToDictionary(kvp => kvp.Key, kvp => (object)kvp.Value);
        }
    }

    internal static bool AreEqual(LocalizableString? left, LocalizableString? right)
    {
        if (left is null && right is null)
        {
            return true;
        }

        if (left is null || right is null)
        {
            return false;
        }

        if (left._dictionary.Count != right._dictionary.Count)
        {
            return false;
        }

        foreach (var (key, value) in left._dictionary)
        {
            if (!right._dictionary.TryGetValue(key, out var otherValue))
            {
                return false;
            }
            if (!string.Equals(value, otherValue, StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }
        }

        return true;
    }

    /// <summary>
    /// Gets the translation for the specified language.
    /// </summary>
    /// <param name="key">The language id.</param>
    /// <returns>The translation.</returns>
    /// <exception cref="KeyNotFoundException">The language id does not exist.</exception>"
    public string this[string key]
    {
        get { return _dictionary[key]; }
    }
}