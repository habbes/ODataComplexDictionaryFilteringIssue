﻿using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace Test;

public class TestDbContext(IConfiguration configuration) : DbContext
{
    private readonly bool _inMemory = configuration.GetValue<bool>("InMemoryDb");

    public DbSet<Customer> Customers { get; set; } = null!;

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        base.OnConfiguring(optionsBuilder);
        if (_inMemory)
        {
            optionsBuilder.UseInMemoryDatabase("TestDb");
        }
        else
        {
            optionsBuilder.UseSqlite("Data Source=Test.db");
        }
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.Entity<Customer>()
            .HasData(
                new Customer
                {
                    Id = 1,
                    Name = new LocalizableString(new Dictionary<string, string>
                    {
                        { "en", "John Doe" },
                        { "fr", "Jean Dupont" }
                    })
                },
                new Customer
                { 
                    Id = 2,
                    Name = new LocalizableString(new Dictionary<string, string>
                    {
                        { "en", "Robert Williams" },
                        { "fr", "Robert Guillaume" }
                    })
                },
                new Customer
                {
                    Id = 3,
                    Name = new LocalizableString(new Dictionary<string, string>
                    {
                        { "en", "John Smith" },
                        { "fr", "Jean Lefevre" }
                    })
                });
        modelBuilder.Entity<Customer>().Property(c => c.Name).HasJsonConversion();
    }
}

public static class Extensions
{
    private static readonly JsonSerializerOptions _serializerOptions = new JsonSerializerOptions();

    public static PropertyBuilder<LocalizableString> HasJsonConversion(this PropertyBuilder<LocalizableString> propertyBuilder)
    {
        var converter = new ValueConverter<LocalizableString, string>(
            v => JsonSerializer.Serialize(v.ExtendedProperties, _serializerOptions),
            v => new LocalizableString(JsonSerializer.Deserialize<Dictionary<string, string>>(v, _serializerOptions) ?? new()));

        var comparer = new ValueComparer<LocalizableString>(
            (l, r) => LocalizableString.AreEqual(l, r),
            v => JsonSerializer.Serialize(v.ExtendedProperties, _serializerOptions).GetHashCode(),
            v => new LocalizableString(v.ExtendedProperties.ToDictionary(kvp => kvp.Key, kvp => (string)kvp.Value)));

        propertyBuilder.HasConversion(converter);
        propertyBuilder.Metadata.SetValueConverter(converter);
        propertyBuilder.Metadata.SetValueComparer(comparer);
        return propertyBuilder;
    }
}
